﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-FKR965V\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}