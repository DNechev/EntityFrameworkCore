﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new ProductShopContext();
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            var userJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\users.json");
            var productsJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\products.json");
            var categoriesJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\categories.json");
            //Problem 1
            //string result = ImportUsers(context, userJson);

            //Problem 2
            //string result = ImportProducts(context, productsJson);

            //Problem 3
            string result = ImportCategories(context, categoriesJson);

            Console.WriteLine(result);
        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            User[] users = JsonConvert.DeserializeObject<User[]>(inputJson)
                .Where(u => u.LastName != null && u.LastName.Length >= 3)
                .ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            Product[] products = JsonConvert.DeserializeObject<Product[]>(inputJson)
                .Where(p => p.Name.Length >= 3 && p.Price != null && p.SellerId != null)
                .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }

        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            Category[] categories = JsonConvert.DeserializeObject<Category[]>(inputJson)
                .Where(c => c.Name != null && c.Name.Length >= 3 && c.Name.Length <= 15 )
                .ToArray();

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count()}";
        }
    }
}