﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.DTOs.Export;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new ProductShopContext();
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            var userJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\users.json");
            var productsJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\products.json");
            var categoriesJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\categories.json");
            var categoriesProductsJson = File.ReadAllText(@"C:\Users\dido9\Desktop\CurrentLecture\ProductShop\ProductShop\Datasets\categories-products.json");

            //Problem 1
            //string result = ImportUsers(context, userJson);

            //Problem 2
            //string result = ImportProducts(context, productsJson);

            //Problem 3
            //string result = ImportCategories(context, categoriesJson);

            //Problem 4
            //string result = ImportCategoryProducts(context, categoriesProductsJson);

            //Problem 5
            string result = GetProductsInRange(context);

            Console.WriteLine(result);
        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            User[] users = JsonConvert.DeserializeObject<User[]>(inputJson)
                .Where(u => u.LastName != null && u.LastName.Length >= 3)
                .ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }

        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            Product[] products = JsonConvert.DeserializeObject<Product[]>(inputJson)
                .Where(p => p.Name.Length >= 3 && p.Price != null && p.SellerId != null)
                .ToArray();

            context.Products.AddRange(products);
            context.SaveChanges();

            return $"Successfully imported {products.Count()}";
        }

        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            Category[] categories = JsonConvert.DeserializeObject<Category[]>(inputJson)
                .Where(c => c.Name != null && c.Name.Length >= 3 && c.Name.Length <= 15 )
                .ToArray();

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count()}";
        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
        {
            CategoryProduct[] categoriesProducts = JsonConvert.DeserializeObject<CategoryProduct[]>(inputJson);

            context.CategoryProducts.AddRange(categoriesProducts);
            context.SaveChanges();

            return $"Successfully imported {categoriesProducts.Count()}";
        }

        public static string GetProductsInRange(ProductShopContext context)
        {
            var products = context.Products
                .Where(p => p.Price >= 500 && p.Price <= 1000)
                .Select(p => new ProductDto
                {
                    Name = p.Name,
                    Price = p.Price,
                    Seller = $"{p.Seller.FirstName} {p.Seller.LastName}"
                }
                )
                .OrderBy(p => p.Price)
                .ToArray();

            var json = JsonConvert.SerializeObject(products, Formatting.Indented);

            return json;
        }
    }
}