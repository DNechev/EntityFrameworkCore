﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => @"Server=DESKTOP-FKR965V\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
