﻿namespace BookShop
{
    using Data;
    using Initializer;
    using System;
    using BookShop.Models.Enums;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using (var db = new BookShopContext())
            {
                string command = Console.ReadLine();
                string result = string.Empty;
                //DbInitializer.ResetDatabase(db);
                result = GetBooksByAgeRestriction(db, command);
                Console.WriteLine(result);
            }
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var ageRestriction = Enum.Parse<AgeRestriction>(command, true);

            var books = context.Books
                .Where(a => a.AgeRestriction == ageRestriction)
                .Select(t => t.Title)
                .OrderBy(t => t)
                .ToArray();


            StringBuilder result = new StringBuilder();

            foreach (var book in books)
            {
                result.AppendLine(book);
            }

            return result.ToString();
        }
    }
}
